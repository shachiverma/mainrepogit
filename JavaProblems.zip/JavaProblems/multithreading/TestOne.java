public class TestOne {

    public static void main(String[] args){

        One one = new One();
        Thread thread = new Thread(one);
        thread.start();

        for(;;){
            System.out.println(Thread.currentThread().getName());
        }
    }
}
