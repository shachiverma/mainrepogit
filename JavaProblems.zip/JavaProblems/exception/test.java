public static int test(){
    int x=0;
    try{
        x=1;
        return x;
    }
    finally{
        x=2;
    }
}
public static void main(){
    System.out.println("returned value is " +test());
}