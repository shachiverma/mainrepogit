public class test1 {

    public static int demo(){
        int x=0;
        try {
            x=1;
            return x;
        }
        finally {
            x=2;
            return x;
        }
    }
    public static void main(){
        System.out.println("returned value is: "+ demo());
    }
}

