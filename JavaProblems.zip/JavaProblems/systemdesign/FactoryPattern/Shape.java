package FactoryPattern;

public interface Shape {

    void draw();
}
