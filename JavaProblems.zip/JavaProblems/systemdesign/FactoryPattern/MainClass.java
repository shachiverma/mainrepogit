package FactoryPattern;

public class MainClass {
    public static void main(String[]args){
        ShapeFactory shapeFactory = new ShapeFactory();
        Shape shape = shapeFactory.getShape("Circle");
        shape.draw();

       // This is not efficient!
//        Shape shape = new Circle();
//        Shape shape2  = new Rectangle();
//        shape.draw();
//        shape2.draw();


    }
}
