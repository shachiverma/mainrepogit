package Singleton;

public class SynchronizationBlock {

    private static SynchronizationBlock obj;
    private SynchronizationBlock(){}

    public static synchronized SynchronizationBlock getInstance(){
        if (obj == null){
            obj = new SynchronizationBlock();
        }
        return obj;
    }
}
