package Singleton;

enum Enum_Singleton {
    INSTANCE;
}
