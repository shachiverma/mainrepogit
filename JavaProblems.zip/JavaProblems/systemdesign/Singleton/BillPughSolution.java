package Singleton;

public class BillPughSolution {

    private BillPughSolution(){}

    private static class BillPughSolutionHelper{
        private static final BillPughSolution INSTANCE_OBJ = new BillPughSolution();
    }
//    we are using a private static nested class because all the nested classes do
//        not get loaded in the memory when you start the application.
//        They only get loaded when they are required;

    public static BillPughSolution getInstance(){
        return BillPughSolutionHelper.INSTANCE_OBJ;
    }
}
