package Singleton;

public class DoubleCheckLock
{
    private static volatile DoubleCheckLock obj;
    private DoubleCheckLock(){}

    public static DoubleCheckLock getInstance(){
        if (obj == null ){
            synchronized (DoubleCheckLock.class){
                if(obj == null){
                    obj = new DoubleCheckLock();
                }
            }
        }
        return obj;
    }
}
