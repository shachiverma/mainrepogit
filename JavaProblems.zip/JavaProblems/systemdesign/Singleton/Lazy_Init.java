package Singleton;

public class Lazy_Init {

    private static Lazy_Init obj;

    private Lazy_Init(){}

    public static Lazy_Init getInstance(){
        if (obj == null){
            obj = new Lazy_Init();
        }
        return obj;
    }
}
