import java.util.Scanner;
//Example 1:
//Input Format:  array[] = {3,1,2,5,3}
//Result: {3,4)
//Explanation: A = 3 , B = 4
//Since 3 is appearing twice and 4 is missing
//
//Example 2:
//Input Format: array[] = {3,1,2,5,4,6,7,5}
//Result: {5,8)
//Explanation: A = 5 , B = 8
//Since 5 is appearing twice and 8 is missing
//This is a maths problem (n*(n+1))/2; and (n*(n+1)*(2*n+1))/6;

public class MissingAndRepeatingNumber {
    public static void main(String []args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of an array");
        int n = sc.nextInt();
        int[] arr = new int[n];
        System.out.println("Enter elements in array");
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }


    }
}
