import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;

public class FrequencyOfElementsInArray {

    public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of an array");
        int n= sc.nextInt();
        int []nums = new int[n];
        System.out.println("Enter the elements in the array");
        for(int i =0;i<n;i++){
            nums[i] = sc.nextInt();
        }

        HashMap<Integer, Integer> integerHashMap = new HashMap<>();


        for(int i: nums) {
            if (!integerHashMap.containsKey(i))
            {
                integerHashMap.put(i, 1);
            }
            else
            {
                integerHashMap.put(i, integerHashMap.get(i)+1);
            }
        }
        System.out.println("Frequency of elements:");
        for (var entry : integerHashMap.entrySet()) {
            System.out.println(entry.getKey() + " → " + entry.getValue());
        }

        }

    }

