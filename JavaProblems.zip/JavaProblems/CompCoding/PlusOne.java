public class PlusOne {
    public static void main(String[]args){
        int[] digits = {1,2,3};
        for(int i=0;i< digits.length;i++){
            
        }
    }
}
