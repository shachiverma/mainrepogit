public class HasSameDigitsAfterOperations {
}
