
public class AnagramsInList {

    public static void main(){


    }
}
