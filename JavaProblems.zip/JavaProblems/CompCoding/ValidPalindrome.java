public class ValidPalindrome {
    public static void main(String[]args){
        String s = " ";
        StringBuilder t= new StringBuilder();

        for(char c : s.toCharArray()){
            if(Character.isLetter(c)){
                t.append(c);
            }
        }
        String str = t.toString().toLowerCase();

        int n = str.length();
        int left = 0;
        int right = n-1;
        boolean isPalindrome = true;
        while(left< right)
        {
         if(str.charAt(left++) != str.charAt(right--)){
             isPalindrome = false;
             break;
         }
        }
        System.out.println(isPalindrome);
    }
}
