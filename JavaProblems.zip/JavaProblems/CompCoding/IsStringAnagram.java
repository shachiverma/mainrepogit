import java.util.Arrays;
import java.util.Scanner;

public class IsStringAnagram {

    public static void main(String []args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the first String");
        String s1 = sc.next();
        System.out.println("Enter the second String");
        String s2 = sc.next();

        int[] freq = new int[26];

        if (s1.length() != s2.length()) {
            System.out.println("Not Anagram");
        }
        else{

            for(int i=0; i<s1.length(); i++) {
                    freq[s1.charAt(i) - 'a']++;
                    freq[s2.charAt(i) - 'a']--;
            }
            boolean isAnagram = true;
            for (int count : freq) {
                if (count != 0) {
                    isAnagram = false;
                    break;
                }
            }

            if (isAnagram)
                System.out.println("Anagram");
            else
                System.out.println("Not Anagram");
        }

        sc.close();
    }
//        else{
//            char[] arr1 = s1.toCharArray();
//            char[] arr2 = s2.toCharArray();
//            Arrays.sort(arr1);
//            Arrays.sort(arr2);
//            String sortedS1 = new String (arr1);
//            String sortedS2 = new String (arr2);
//            if(sortedS1.equals(sortedS2)){
//                System.out.println("Anagram");
//            }
//            else{
//                System.out.println("Not Anagram");
//            }
//        }
    }

//The above commented method is also best approach.
