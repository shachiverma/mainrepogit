import java.util.HashMap;

public class IsomorphicStrings {
    public static void main(String []args){
        String s= "foo";
        String t= "bar";
        int n = s.length();

        int []mapS = new int[256];
        int []mapT = new int[256];

        for(int i =0; i<n;i++){
            char ch1 = s.charAt(i);
            char ch2 = t.charAt(i);

            if(mapS[ch1] ==0 && mapT[ch2] == 0){
                mapS[ch1] = ch2;
                mapT[ch2] = ch1;
            }
            else if(mapS[ch1] != ch2 || mapT[ch2]!=ch1){
                System.out.println(false);
                return;
            }
        }
        System.out.println(true);

    }
}
