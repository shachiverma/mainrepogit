
public class ReverseEachCharacterInAString {
    public static void main(String []args){
        String str= "Let's take LeetCode contest";

        StringBuilder rev = new StringBuilder();
        StringBuilder temp = new StringBuilder();

        for(int i =0; i< str.length(); i++){
            char ch = str.charAt(i);
            if(ch == ' ')
            {
                rev.append(reverseK(String.valueOf(temp)));
                rev.append(" ");
                temp.setLength(0);
            }
            else{
                temp.append(ch);
            }

        }
        rev.append(reverseK(String.valueOf(temp))); // appending the last word
        System.out.println(rev.toString());


    }
    private static String reverseK(String t){
        char[]c = t.toCharArray();
        char temp;
        int first=0;
        int last = t.length()-1;
        while(first<last){
           temp = c[first];
           c[first]= c[last];
           c[last]= temp;
           first++;
           last--;
        }
        return new String(c);
    }
}
