import java.util.Scanner;

public class UglyNumber {

    public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter any number");
        int num = sc.nextInt();
        isUgly(num);
    }

    private static void isUgly(int num) {
        while(num > 1) {
            if (num % 2 == 0) {
                num = num / 2;
            } else if (num % 3 == 0) {
                num = num / 3;
            } else if (num % 5 == 0) {
                num = num / 5;
            } else {
                System.out.println("Not Ugly");
                return;
            }
        }
        if (num == 1)
        {System.out.println("Is Uglyy");}
        else {
            System.out.println("Not Ugllly");
        }
    }

}