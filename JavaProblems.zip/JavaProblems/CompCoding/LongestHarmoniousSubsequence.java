import java.util.HashMap;

public class LongestHarmoniousSubsequence {
    public static void main(String[] args) {
//        We define a harmonious array as an array where the
//        difference between its maximum value and its minimum value is exactly 1.
        int[] nums = {1, 3, 2, 2, 5, 2, 3, 7};
        int maxN = 0;
        int result = 0;

        //Create a hashmap for storing frequency
        //check if hashmap has minN+1 key if yes : count the freq and return
        HashMap<Integer, Integer> map = new HashMap<>();
        for(int n: nums){
            map.put(n, map.getOrDefault(n,0)+1);
        }
        for(int key: map.keySet()){
            if(map.containsKey(key+1)){
                result = Math.max(result, map.get(key)+map.get(key+1));
            }
        }
        System.out.println(result);
    }
}
