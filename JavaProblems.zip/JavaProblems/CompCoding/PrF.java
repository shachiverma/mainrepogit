public class PrF {
   public static void main(String[]args){

       int l= 100;
       int x=0;
       int y =1;
       int z = x+y;

       while(z<=l){
           if(Prime(z)){
               System.out.print(z+ " ");
           }
           x=y;
           y=z;
           z=x+y;
       }
   }
   //Prime check
    public static boolean Prime(int num){
        if(num<2){return false;}
        for(int i=2; i<=Math.sqrt(num);i++){
            if(num % i ==0){
                return false;
            }
        }
        return true;
    }

}




