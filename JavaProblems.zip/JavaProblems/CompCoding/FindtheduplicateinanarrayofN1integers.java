// Input [1,4,4,2,4]
// 4
import java.util.Scanner;

public class FindtheduplicateinanarrayofN1integers {

    public static void main(String []args){
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter the size of an array");
    int n = sc.nextInt();
    int []arr = new int[n];
    System.out.println("Enter elements in array");
    for(int i =0;i<n;i++){
        arr[i]= sc.nextInt();
    }
    int []nums = new int[n+1];
    int result = 0;
    for(int i =0;i<n;i++){
        if(nums[arr[i]]==0){
            nums[arr[i]]+=1;
        }
        else {
          result = arr[i];
        }
    }
        System.out.println(result);

  }
}
