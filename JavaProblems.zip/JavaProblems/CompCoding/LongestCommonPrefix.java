import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class LongestCommonPrefix {

    public static void main(String[]args){
        List<String> str = Arrays.asList("flower","cat","dog");
        System.out.println(commonPrefix(str));

    }
    private static StringBuilder commonPrefix(List<String> str) {
        List<String> sortedStr = str.stream().sorted().collect(Collectors.toList());
        StringBuilder prefix = new StringBuilder();

        char[] firstWord = sortedStr.get(0).toCharArray();
        char[] lastWord = sortedStr.getLast().toCharArray();

        for(int i=0; i<Math.min(firstWord.length, lastWord.length); i++){
            if(firstWord[i] != lastWord[i]){
                return prefix;
            }
            prefix.append(firstWord[i]);
        }
        return prefix;
    }
}
