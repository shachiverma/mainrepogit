import java.util.Scanner;

import static java.lang.Math.abs;

public class ReverseInteger {

    public static void main(String[]args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number");
        int num = sc.nextInt();
        int reversed =0;
        int nums= num;
        if(num < 0)
        {
           nums = abs(num);
        }
        while(nums!=0){
            int rem = nums%10;
            reversed = reversed * 10 + rem;
            nums = nums/10;
        }
        if(num < 0) {
            System.out.println("Reversed :" + "-" + reversed);
        }
        else {System.out.println("Revrsed :"+ reversed);}
    }
}



