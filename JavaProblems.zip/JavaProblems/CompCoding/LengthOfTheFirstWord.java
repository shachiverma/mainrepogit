import java.util.Scanner;

public class LengthOfTheFirstWord {

    public static void main(String[]args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the first String");
        String s = sc.nextLine();

        int length = 0;
        for (int i=0; i <= s.length() - 1;  i++) {
            if (s.charAt(i) != ' ') {
                length++;
            } else if (length > 0) {
                break;
            }
        }
        System.out.println(length);
    }
}
