import java.util.Scanner;

public class MergeSortedArrays {
    public static void main(String[]args){
        Scanner sc = new Scanner(System.in);
        int m = sc.nextInt();
        int n = sc.nextInt();
        int [] nums1 = new int [m];
        int [] nums2 = new int [n];
        for (int i=0;i<nums1.length;i++){
            nums1[i]=sc.nextInt();
        }
        for (int i=0;i<nums2.length;i++){
            nums2[i]=sc.nextInt();
        }
        merge(nums1, m, nums2, n);

    }

    private static void merge(int []arr1, int m, int []arr2, int n) {
       int leftPointer = 0;
       int rightPointer = 0;
       int indexPointer = 0;
       int []arr3 = new int [n+m];

       while(leftPointer < m && rightPointer < n){
            if(arr1[leftPointer] <= arr2[rightPointer]){
                arr3[indexPointer] = arr1[leftPointer];
                indexPointer++;
                leftPointer++;
            }
            else{
                arr3[indexPointer] = arr2[rightPointer];
                indexPointer++;
                rightPointer++;
            }
       }
       while(leftPointer < m){
        arr3[indexPointer++]=arr1[leftPointer++];
       }
       while(rightPointer < n ){
        arr3[indexPointer++] = arr2[rightPointer++];
       }

    //    for (int i =0;i<n+m;i++){
    //      if (i<m){arr1[i]=arr3[i];}
    //      else{arr2[i-m]=arr3[i];}
    //    }
    for(int i=0;i<n+m;i++){
        System.out.print(" "+ arr3[i]);
    }
    }
}
