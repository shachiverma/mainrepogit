//Example 1:
//
//Input: nums = [2,3,-2,4]
//Output: 6
//Explanation: [2,3] has the largest product 6.
//Example 2:
//
//Input: nums = [-2,0,-1]
//Output: 0
//Explanation: The result cannot be 2, because [-2,-1] is not a subarray.

import java.util.Scanner;

import static java.lang.Math.max;

public class MaximumProductArray
{
    public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of the array");
        int num = sc.nextInt();
        System.out.println("Enter array");
        int [] arr = new int[num];
        for(int i=0;i<num;i++){
             arr[i]= sc.nextInt();
        }

        int l=1;
        int r=1;
        int ans = arr[0];

        for(int i =0;i<num;i++){

            //whenever the l and r are 0 we assign the value 1 to them.
            l= l==0 ? 1: l;
            r= r==0 ? 1: r;

            l = l * arr[i];
            r= r * arr[num-1-i];

            ans = max(ans, max(l,r));
        }

        System.out.println("The maximum product of subarray is : "+ans );
    }

}

