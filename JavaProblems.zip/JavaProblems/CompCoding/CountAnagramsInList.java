public class CountAnagramsInList {
}
