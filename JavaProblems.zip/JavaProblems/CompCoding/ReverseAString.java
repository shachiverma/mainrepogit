import java.util.Stack;

public class ReverseAString {
//    public static void main(String[] args){
//       String s1 = "hello";
//       Stack<Character> st = new Stack<>();
//       for(char ch : s1.toCharArray()){
//            st.push(ch);
//       }
//       StringBuilder reversed= new StringBuilder();
//       while(!st.isEmpty()){
//           reversed.append(st.pop());
//       }
//       System.out.println(reversed);
//    }

    public static void main(String[] args){
        String str = "hello";
        char[] arr = str.toCharArray();

        int left =0;
        int right = str.length()-1;
        while(left<right){
            char temp = arr[left];
            arr[left] = arr[right];
            arr[right] = temp;
            left++;
            right--;

        }
        String reversed = new String(arr);
        System.out.println(reversed);
    }
}
