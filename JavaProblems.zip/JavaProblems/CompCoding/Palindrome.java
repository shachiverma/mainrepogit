public class Palindrome {
    public static void main(String args[]){
        boolean isPalindrome = true;
        String s= "malayalam";
        int start = 0;
        int end= s.length()-1;
        char []ch = s.toCharArray();
        while(start<end){
            if(ch[start]!=ch[end])
            {
                isPalindrome=false;
                break;
            }
            start++;
            end--;
        }
        System.out.println(isPalindrome);
    }
}
