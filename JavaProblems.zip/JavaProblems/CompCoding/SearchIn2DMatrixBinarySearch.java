import java.util.Scanner;

public class SearchIn2DMatrixBinarySearch {
    public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of rows: ");
    int n = sc.nextInt();
        System.out.print("Enter number of columns: ");
    int m = sc.nextInt();

        System.out.print("Enter the target: ");
    int target = sc.nextInt();

    int[][] matrix = new int[n][m];
        System.out.println("Enter matrix elements:");
        for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            matrix[i][j] = sc.nextInt();
        }
    }

    // Call search
    boolean res = search(matrix, target);
        System.out.println(res);
}

public static boolean search(int[][]matrix, int target){

        return false;

}
}
