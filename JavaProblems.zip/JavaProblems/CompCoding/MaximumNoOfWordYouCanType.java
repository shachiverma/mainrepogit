import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;

public class MaximumNoOfWordYouCanType {

    public static void main(String[]args){
        Scanner sc = new Scanner(System.in);
        System.out.println("enter string");
        String text = sc.nextLine();
        System.out.println("enter brokenLetters");
        String brokenLetters = sc.nextLine();

        HashSet<Character> set = new HashSet<>();

        String[] words = text.split(" ");

        for(char ch : brokenLetters.toCharArray()){
            set.add(ch);
        }
        int ans =0;
        for(String word: words){
            boolean canType = true;
            for(char ch : word.toCharArray()){
                if(set.contains(ch)){
                    canType = false;
                    break;
                }
            }
            if(canType){ans++;}
        }
        System.out.println(ans);
    }
}
