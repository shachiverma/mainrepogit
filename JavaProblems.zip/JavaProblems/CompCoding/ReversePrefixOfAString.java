public class ReversePrefixOfAString {
    public static void main(){
        String s = "abcdefd";
        char ch = 'd';

        StringBuilder sb = new StringBuilder();
        StringBuilder temp = new StringBuilder();
        int start =0;
        int end;
        for(int i=0;i<s.length();i++){
            char c = s.charAt(i);
            if(c == ch){

                sb.append(temp.reverse());
                System.out.println(sb.toString());
                break;
            }
            else{
                temp.append(c);
            }
        }
    }
}
