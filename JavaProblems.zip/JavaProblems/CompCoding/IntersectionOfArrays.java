import java.util.Arrays;
import java.util.HashSet;

public class IntersectionOfArrays {
    public static void main(String[]args){

        int []nums1 = {1,1,2,3}; //1,1,2,3
        int []nums2 = {4,5,6,2,1,3}; // 1,2,3,4,5,6
        //Create a hashset and sort both arrays

        HashSet<Integer> hSet = new HashSet<>();
        Arrays.sort(nums1);
        Arrays.sort(nums2);

        int i =0;
        int j =0;
        while(i < nums1.length && j < nums2.length){
            if(nums1[i]<nums2[j]){
                i++;
            }
            else if(nums1[i]>nums2[j]){
                j++;
            }
            else{
                hSet.add(nums2[j]);
                i++;
                j++;
            }
        }
        int k =0;
        int []nums3 = new int [hSet.size()];
        for(int n: hSet) {
            nums3[k] = n;
            System.out.println(nums3[k]);
            k++;
        }



    }
}
