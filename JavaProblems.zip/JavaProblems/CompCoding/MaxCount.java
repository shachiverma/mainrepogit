import java.util.HashSet;
import java.util.Scanner;

public class MaxCount {

    public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of an array");
        int n= sc.nextInt();
        int []nums = new int[n];
        System.out.println("Enter the elements in the array");
        for(int i =0;i<n;i++){
           nums[i] = sc.nextInt();
        }
        System.out.println(ifNumberIsAlreadyPresent(n, nums));
    }

    private static boolean ifNumberIsAlreadyPresent(int n , int []nums) {
        HashSet<Integer> integerHashSet = new HashSet<>();
        for(int i: nums){
            if(integerHashSet.contains(nums[i])){
                return true;
            }
            else {
                integerHashSet.add(nums[i]);
            }
        }
        return false;
    }
}

