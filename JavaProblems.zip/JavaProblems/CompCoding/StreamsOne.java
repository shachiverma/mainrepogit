import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.Scanner;
import java.util.stream.Collectors;

public class StreamsOne {

    public static void main(String[]args){
        Scanner sc = new Scanner(System.in);

        List<Integer> arr = Arrays.asList(1,2,3,4,5,6,7,8,9,10,11,12);
        List<Integer> list1 = arr.stream().filter(n->n%2 ==0).collect(Collectors.toList());

        System.out.println(list1);//outputs even numbers

        List<Integer> list2 = arr.stream().filter(n->n%2 ==0).map(m->m*m).collect(Collectors.toList());
        System.out.println(list2);//squared each number

        Optional<Integer> firstNumberGreaterThanFive = arr.stream().filter(n-> n > 5).findFirst();
        System.out.println(firstNumberGreaterThanFive);

        //count how many numbers are greater than 5 in a list ?
        long numGreaterThanFive = arr.stream().filter(n->n >5).count();
        System.out.println(numGreaterThanFive);

        //find sum/product of all integers in the list
        int sumOfNumbers = arr.stream().mapToInt(Integer::intValue).sum();
        System.out.println(sumOfNumbers);

        int productOfNumbers = arr.stream().reduce(1,(a,b)->a*b);
        System.out.println(productOfNumbers);

        //sum of squares of even numbers
        int sumOfSquareOfEvenNums = arr.stream().filter(n->n%2 ==0).map(m->m*m).mapToInt(Integer::intValue).sum();
        System.out.println(sumOfSquareOfEvenNums);

        //maximum number in a list
        OptionalInt maximumNum = arr.stream().mapToInt(Integer::intValue).max();
        if(maximumNum != null){
            System.out.println(maximumNum.getAsInt());
        }

        List<Employee> employees = Arrays.asList(
                new Employee("1","Shachi","IT",2000000),
                new Employee("2","Michelle","HR",100000),
                new Employee("1","Monrone","CyberSecurity",500000));

        //group employees by department
        Map<String, List<Employee>> groupingByDepartment = employees
                .stream()
                .collect(Collectors.groupingBy(Employee::getDepartment));

        //printing the grouped employees
//        groupingByDepartment.forEach(
//                (department, employeeList)->
//                {
//                System.out.println("Department "+ department);
//                employeeList.forEach(System.out::println);
//                }
//        );

        //find employees with salary less
        Map<Boolean, List<Employee>> partitionBySalary = employees
                .stream()
                .collect(Collectors.partitioningBy(employee -> employee.getSalary()> 100000));

        //employees with salary greater than 100000
        partitionBySalary.get(true).forEach(System.out::println);
        //employees with salary lesser than 100000
        partitionBySalary.get(false).forEach(System.out::println);


    }
}
