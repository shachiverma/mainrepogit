import java.util.HashMap;
import java.util.Map;

public class FrequencyOfCharacterInString {
    public static void main(String[] args) {
        String str = "balloon";
        str = str.toLowerCase(); // ignore case

        Map<Character, Integer> frequencyMap = new HashMap<>();

        for (char ch : str.toCharArray()) {
            if (ch >= 'a' && ch <= 'z') { // only alphabets
                frequencyMap.put(ch, frequencyMap.getOrDefault(ch, 0) + 1);
            }
        }

        // Print result
        for (Map.Entry<Character, Integer> entry : frequencyMap.entrySet()) {
            System.out.println(entry.getKey() + " → " + entry.getValue());
        }
    }

}
