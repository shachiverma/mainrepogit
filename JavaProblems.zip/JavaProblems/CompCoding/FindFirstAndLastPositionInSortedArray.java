import java.util.Arrays;

public class FindFirstAndLastPositionInSortedArray {
    public static void main(String[]args) {
        int[] nums = {5, 7, 7, 8, 8, 10};
        int target = 8;
        //Output [3,4]
        int[] ans = searchRange(nums, target);

        System.out.println(Arrays.toString(ans));
    }
        private static int[] searchRange(int []nums, int target){

            int first = findFirst(nums, target);
            int last = findLast(nums, target);
            return new int[]{first, last};
        }

    private static int findLast(int[] nums, int target) {
        int left =0;
        int right= nums.length-1;
        int result = -1;
        while(left<=right){
            int mid = (left+right)/2;
            if(nums[mid] == target){
               result = mid;
               left = mid + 1; // move right to find last
            }
            else if(nums[mid]<target){
                left = mid+1;
            }
            else{right = mid-1;}
        }
        return result;
    }

    private static int findFirst(int[] nums, int target) {
        int left =0;
        int right= nums.length-1;
        int result = -1;
        while(left<=right){
            int mid = (left+right)/2;
            if(nums[mid] == target){
                result = mid;
                right = mid - 1; // move left to find first
            }
            else if(nums[mid]<target){
                left = mid+1;
            }
            else{right = mid-1;}
        }
        return result;
    }
}


