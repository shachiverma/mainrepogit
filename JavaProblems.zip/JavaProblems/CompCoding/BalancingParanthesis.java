import java.util.Scanner;
import java.util.Stack;

public class BalancingParanthesis {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the braces");
        String braces = sc.next();
        Stack<Character> stack = new Stack<>();

        for (char bracket : braces.toCharArray()) {
            if (bracket == '(') {
                stack.push(')');
            } else if (bracket == '{') {
                stack.push('}');
            } else if (bracket == '[') {
                stack.push(']');
            } else if (stack.isEmpty() || stack.peek() != bracket) {
                System.out.println("false");
                return;
            } else {
                stack.pop();
            }
        }
        System.out.println(stack.isEmpty() ? "true" : "false");
    }
}
