////import java.util.Scanner;
////
////public class Fib1 {
//////    0 1, 1, 2, 3, 5,8
////
////    public static void main(){
////        Scanner sc = new Scanner(System.in);
////        System.out.println("Enter the num");
////        int num = sc.nextInt();
////        solveFib(num);
////    }
////    static int solveFib(int n) {
////        if (n <= 1) {
////            return n;
////        }
////        return solveFib(n - 1) + solveFib(n - 2);
////    }
////}
//
//class Parent {
//    public static void show() {
//        System.out.println("Parent static");
//    }
//    public void display() {
//        System.out.println("Parent instance");
//    }
//}
//
//class Child extends Parent {
//    public static void show() {
//        System.out.println("Child static");
//    }
//    public void display() {
//        System.out.println("Child instance");
//    }
//}
//
//public class TestClass {
//    public static void main(String[] args) {
//        Parent p = new Child();
//        p.show();
//        p.display();
//    }
//}
//***************************************************************
//class A {}
//class B extends A {}
//
//public class TestClass {
//    public static void main(String[] args) {
//        process(null);
//    }
//
//    public static void process(A a) {
//        System.out.println("A method");
//    }
//
//    public static void process(B b) {
//        System.out.println("B method");
//    }
//}
