import java.util.Scanner;

public class Fibonacci {
    public static void main(String []args){
        System.out.println("Enter the number");
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        int res = solve(num);
        System.out.println("The value is :"+res);
    }

    private static int solve(int num) {
        if(num<=1){
            return num;
        }
        int a=0;
        int b=1;
        int c=0;
        for(int i =1;i<num;i++) {

            c= a+b;
            a = b;
            b = c;
        }
        return c;
    }
}