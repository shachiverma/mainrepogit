import java.util.Scanner;

public class RemoveElements {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter size of array");
        int n = sc.nextInt();
        int[] nums = new int[n];
        System.out.println("Enter numbers in array");
        for (int i = 0; i < n; i++) {
            nums[i] = sc.nextInt();
        }
        System.out.println("enter the element you want to remove from array");
        int k = sc.nextInt();
        int newLength = removeElement(nums, k);
        for(int i=0;i<newLength;i++){
            System.out.println(nums[i]);
        }

    }

    public static int removeElement(int nums[], int k) {
        int index = 0;
        for (int i = 0; i < nums.length; i++) {
            if (nums[i] != k) {
                nums[index] = nums[i];
                index++;
            }
        }
        return index;
    }
}
