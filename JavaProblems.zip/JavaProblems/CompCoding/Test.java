public class Test
{
    public static void main(String[]args){
    String s1= new String("spring");
    s1.concat("summer");
    String s2 = s1.concat("winter");
    s1 = s1.concat("fall");
        System.out.println(s1);
        System.out.println(s2);
    }
}
//8-->springsummerfall
//9-->springwinter