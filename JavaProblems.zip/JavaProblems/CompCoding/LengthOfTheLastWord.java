import java.util.Scanner;

public class LengthOfTheLastWord {

    public static void main(String[]args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the first String");
        String s = sc.nextLine();

        int length =0;
        for(int i=s.length()-1; i>=0;i--){
            if(s.charAt(i)!= ' ' ){
                length++;
            }
            else if(length>0){break;}
        }
        System.out.println(length);
//        s= s.trim();
//        System.out.println(s);
    }
}
