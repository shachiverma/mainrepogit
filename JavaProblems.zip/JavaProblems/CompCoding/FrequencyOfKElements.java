import java.util.HashMap;
import java.util.Map;

public class FrequencyOfKElements {




}
