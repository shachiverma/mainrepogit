import java.util.Scanner;
//IntuitionalApproach but not optimal so the time complexity in worst case will be O(n*m)
import java.util.Scanner;

public class SearchIn2DMatrix {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of rows: ");
        int n = sc.nextInt();
        System.out.print("Enter number of columns: ");
        int m = sc.nextInt();

        System.out.print("Enter the target: ");
        int target = sc.nextInt();

        int[][] matrix = new int[n][m];
        System.out.println("Enter matrix elements:");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                matrix[i][j] = sc.nextInt();
            }
        }

        // Call search
        boolean res = searchMatrix(matrix, target);
        System.out.println(res);
    }

    public static boolean searchMatrix(int[][] matrix, int target) {
        int n = matrix.length;         // number of rows
        int m = matrix[0].length;      // number of columns

        int i = 0;         // start row
        int j = m - 1;     // start column (top-right corner)

        while (i < n && j >= 0) {
            if (matrix[i][j] > target) {
                j--; // move left
            } else if (matrix[i][j] < target) {
                i++; // move down
            } else {
                return true; // found
            }
        }
        return false; // not found
    }
}
