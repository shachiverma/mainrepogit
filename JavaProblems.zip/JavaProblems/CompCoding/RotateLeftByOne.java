public class RotateLeftByOne {

        public static void main(String[]args) {
            int[] arr = {4, 8, 3, 9, 10, 1, 12};
//          {4, 8, 3, 9, 10, 1, 12}
//          {8,3,9,10,1,12,4}
            int temp= arr[0];
            int n = arr.length;
            for (int i = 0; i < n-1; i++){
                arr[i] = arr[i+1];
            }
            arr[n-1] = temp;
            for(int i=0;i<n;i++){
                System.out.print(arr[i]+" ");
            }

        }


}
