import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class Mat {

    List<String> list = Arrays.asList("hibernate", "java", "python", "php", "microservices", "spring", "go",
            "ruby");

    String longest = list.stream()
            .max(Comparator.comparingInt(String::length)) // compare by length
            .orElse("");

    public static void main(String[] args) {
        List<String> list = Arrays.asList("abc", "baa", "xyz", "pqrs", "xyz", "abc");

        List<String> list2 = Arrays.asList("hibernate", "java", "python", "php", "microservices", "spring", "go",
                "ruby");

        String longest = list2.stream()
                .max(Comparator.comparingInt(String::length))
                .orElse("");

        System.out.println("Longest: " + longest);

        int maxLength = list2.stream()
                .mapToInt(String::length)
                .max()
                .orElse(0);

        System.out.println("Longest length: " + maxLength);

        String shortest = list2.stream()
                .min(Comparator.comparingInt(String::length))
                .orElse("");

        System.out.println("Shortest word: " + shortest);

        int minLength = list2.stream()
                .mapToInt(String::length)
                .min()
                .orElse(0);

        System.out.println("Shortest length: " + minLength);


        List<String> res = list.stream().map(map -> map.replaceAll("a", "")).collect(Collectors.toList());
        System.out.println(res);

//    [b, bc, bc, pqrs, xyz, xyz]


        List<String> words = Arrays.asList("Java", "Spring", "Hibernate", "Streams");

        // Fetch first element
        Optional<String> firstWord = words.stream().findFirst();

        //Find the length of the first word
        Optional<Integer> firstWordLength = words.stream().findFirst().map(String::length).stream().findFirst();

        firstWord.ifPresent(System.out::println);  // Output: Java
        firstWordLength.ifPresent(System.out::println);// 4

        //Fetch the last word
        Optional<String> lastWord = words.stream().reduce((first, second) -> second);
        lastWord.ifPresent(System.out::println);

//        Remove all odd numbers
//        Multiply the numbers by any constant
//        then sum it together
        List<Integer> nums = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12);
        int result = nums.stream().filter(n -> n%2 == 0).mapToInt(n -> n * 5).sum();
        System.out.println(result);

    }
}