//Given an unsorted array of integers nums, return the length of the longest consecutive elements sequence.
//
//Input: nums = [100,4,200,1,3,2]
//Output: 4
//
//Input: nums = [1,0,1,2], 0,3,7,2,5,8,4,6,0,1
//Output: 3

import java.util.HashSet;

public class TestMob {
    public static void main(String[]args){
        int curr=0;
        int y=0;
        int l =1;
        int[] arr ={100,4,200,1,3,2};
        HashSet<Integer> set = new HashSet<>();
        for(int i: arr){
            set.add((i));
        }

        for(int it: set){
            if(!set.contains(it-1)){
                int cn =1;
                int x = it;
                curr = it;
                while(set.contains(x+1))
                {
                    x=x+1;
                    cn = cn+1;
                    curr=curr+1;
                }
                l= Math.max(l,cn);
                y=it;

            }
        }
        System.out.println(l);
        for(int i=0;i<l;i++){
            System.out.println(y);
        }
    }
}
//TC = O(n)
//SC = O(n)
