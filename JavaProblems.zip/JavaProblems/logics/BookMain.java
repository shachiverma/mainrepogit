public class BookMain {
    String title;
    int price;

    // Constructor 1
    BookMain() {
        this("Unknown", 0); // calls Constructor 2
    }

    // Constructor 2
    BookMain(String title, int price) {
        this.title = title;
        this.price = price;
    }

    void show() {
        System.out.println(title + " - " + price);
    }


    public static void main(String[] args) {
        BookMain b1 = new BookMain();
        BookMain b2 = new BookMain("Java Basics", 500);
        b1.show();
        b2.show();
    }
}

